from flask import Flask
from flask import render_template
import database_manager as dbHandler


app = Flask(__name__)


@app.route('/index.html', methods=['GET'])
@app.route('/', methods=['POST', 'GET'])
def index():
    data = dbHandler.listExtension()
    return render_template('/index.html', content=data)

@app.route('/profile')
def index1():
    data = dbHandler.listExtension()
    return render_template('/profile.html', content=data)

@app.route('/signup')
def index2():
    data = dbHandler.listExtension()
    return render_template('/signup.html', content=data)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5100)
